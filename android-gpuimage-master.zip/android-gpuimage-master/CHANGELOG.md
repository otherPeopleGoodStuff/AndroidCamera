Change Log
==========

Version 1.2.3-SNAPSHOT *(2014-12-15)*
----------------------------

 * added GPUImageLevelsFilter (by @vashisthg)
